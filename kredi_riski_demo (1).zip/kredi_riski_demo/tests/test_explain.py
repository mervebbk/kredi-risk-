# -*- coding: utf-8 -*-
"""
Otomatik testler.  Çalıştırma (proje klasöründen):   python -m unittest discover -s tests -v

Bu testler, sunumda "açıklamaların doğru olduğunu nasıl kontrol ettiniz?" sorusunun cevabıdır.
"""
import os
import sys
import unittest

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from features import FEATURE_NAMES, FEATURES, model_matrix  # noqa: E402
from explain import (counterfactuals, decide, expected_loss, shapley_sampling)  # noqa: E402
import app as appmod  # noqa: E402

ORTA = dict(yas=31, aylik_gelir=38000, kredi_tutari=280000, vade_ay=36, calisma_yili=4,
            kredi_gecmisi_yil=4, mevcut_borc=90000, gecikme_sayisi=1, kart_kullanim_orani=55, teminat_var=0)
YUKSEK = dict(yas=29, aylik_gelir=28000, kredi_tutari=260000, vade_ay=36, calisma_yili=2,
              kredi_gecmisi_yil=3, mevcut_borc=70000, gecikme_sayisi=2, kart_kullanim_orani=80, teminat_var=0)


def predict_fn_for(key):
    model = appmod.MODELS[key]
    return lambda df: model.predict_proba(df[FEATURE_NAMES])[:, 1]


class TestShapley(unittest.TestCase):
    def test_efficiency_both_models(self):
        """Katkıların toplamı = tahmin - referans (Shapley'in 'verimlilik' özelliği)."""
        for key in ("lr", "gb"):
            for x in (ORTA, YUKSEK):
                phi, base, fx = shapley_sampling(predict_fn_for(key), x, appmod.BACKGROUND, n_samples=200)
                self.assertAlmostEqual(phi.sum(), fx - base, places=9)

    def test_deterministic(self):
        """Aynı girdi, aynı açıklama (tohum sabit; arayüzde titreme olmaz)."""
        a = shapley_sampling(predict_fn_for("gb"), ORTA, appmod.BACKGROUND)[0]
        b = shapley_sampling(predict_fn_for("gb"), ORTA, appmod.BACKGROUND)[0]
        np.testing.assert_allclose(a, b)

    def test_direction_makes_sense(self):
        """Alan bilgisiyle tutarlılık: gecikme ve yüksek kart kullanımı riski artırmalı."""
        phi, _, _ = shapley_sampling(predict_fn_for("lr"), YUKSEK, appmod.BACKGROUND)
        d = dict(zip(FEATURE_NAMES, phi))
        self.assertGreater(d["gecikme_sayisi"], 0)
        self.assertGreater(d["kart_kullanim_orani"], 0)

    def test_dummy_feature_gets_zero(self):
        """Modelin kullanmadığı bir özelliğe katkı verilmemeli (sıfır-katkı özelliği)."""
        cols = FEATURE_NAMES

        def only_income(df):  # sadece aylık gelire bağlı yapay model
            return 1.0 / (1.0 + np.exp((df["aylik_gelir"].to_numpy() - 40000) / 15000.0))

        phi, _, _ = shapley_sampling(only_income, ORTA, appmod.BACKGROUND, n_samples=100)
        for name, v in zip(cols, phi):
            if name != "aylik_gelir":
                self.assertAlmostEqual(v, 0.0, places=12)


class TestCounterfactuals(unittest.TestCase):
    def test_suggestions_really_reach_target(self):
        """Önerilen değişiklikler uygulanınca risk gerçekten hedefin altına inmeli."""
        for key in ("lr", "gb"):
            fn = predict_fn_for(key)
            for x in (ORTA, YUKSEK):
                cf = counterfactuals(fn, x, target=0.20)
                for o in cf["oneriler"]:
                    y = dict(x)
                    for c in o["degisiklikler"]:
                        y[c["name"]] = c["to"]
                    p = float(fn(pd.DataFrame([y]))[0])
                    self.assertLess(p, 0.20)
                    self.assertAlmostEqual(p, o["yeni_risk"], places=9)

    def test_only_actionable_features_change(self):
        """Yaş, gelir, geçmiş gecikme gibi değiştirilemeyen özellikler asla önerilmemeli."""
        allowed = {f["name"] for f in FEATURES if f["actionable"]}
        for key in ("lr", "gb"):
            for x in (ORTA, YUKSEK):
                for o in counterfactuals(predict_fn_for(key), x, 0.20)["oneriler"]:
                    for c in o["degisiklikler"]:
                        self.assertIn(c["name"], allowed)

    def test_already_below_target(self):
        low_risk = dict(yas=42, aylik_gelir=85000, kredi_tutari=150000, vade_ay=36, calisma_yili=14,
                        kredi_gecmisi_yil=12, mevcut_borc=20000, gecikme_sayisi=0, kart_kullanim_orani=15,
                        teminat_var=1)
        cf = counterfactuals(predict_fn_for("gb"), low_risk, 0.20)
        self.assertTrue(cf["zaten_hedefte"])
        self.assertEqual(cf["oneriler"], [])

    def test_loan_floor_respected(self):
        """Kredi tutarı, talep edilenin %40'ından aşağı önerilmemeli."""
        for o in counterfactuals(predict_fn_for("lr"), YUKSEK, 0.20)["oneriler"]:
            for c in o["degisiklikler"]:
                if c["name"] == "kredi_tutari":
                    self.assertGreaterEqual(c["to"], 0.4 * YUKSEK["kredi_tutari"] - 1e-6)


class TestDecision(unittest.TestCase):
    def test_bands(self):
        self.assertEqual(decide(0.10, 0.2, 0.45)["band"], "dusuk")
        self.assertEqual(decide(0.30, 0.2, 0.45)["band"], "orta")
        self.assertEqual(decide(0.60, 0.2, 0.45)["band"], "yuksek")

    def test_expected_loss(self):
        e = expected_loss(0.5, dict(teminat_var=0, kredi_tutari=100000))
        self.assertAlmostEqual(e["el"], 0.5 * 0.45 * 100000)
        e = expected_loss(0.5, dict(teminat_var=1, kredi_tutari=100000))
        self.assertAlmostEqual(e["el"], 0.5 * 0.25 * 100000)


class TestModelAndApi(unittest.TestCase):
    def setUp(self):
        self.client = appmod.app.test_client()

    def test_model_matrix_shape(self):
        m = model_matrix(pd.DataFrame([ORTA])[FEATURE_NAMES])
        self.assertEqual(m.shape, (1, 12))
        self.assertTrue(np.isfinite(m).all())

    def test_metrics_reasonable(self):
        for k, m in appmod.META["metrics"].items():
            self.assertGreater(m["roc_auc"], 0.70, k)
            self.assertLess(m["roc_auc"], 0.99, k)  # çok yüksekse veri sızıntısından şüphelenilir

    def test_api_ok(self):
        r = self.client.post("/api/predict", json=dict(features=ORTA, model="gb"))
        self.assertEqual(r.status_code, 200)
        j = r.get_json()
        self.assertTrue(0 <= j["risk"] <= 1)
        self.assertLess(abs(j["phi_sum_check"]), 1e-9)
        self.assertEqual(len(j["contributions"]), len(FEATURES))

    def test_api_validation(self):
        bad = dict(ORTA)
        del bad["yas"]
        self.assertEqual(self.client.post("/api/predict", json=dict(features=bad)).status_code, 400)
        self.assertEqual(self.client.post("/api/predict", json=dict(features=ORTA, model="x")).status_code, 400)
        self.assertEqual(self.client.post("/api/predict", json=dict(features=ORTA, low=0.6, high=0.3)).status_code, 400)
        notnum = dict(ORTA, yas="abc")
        self.assertEqual(self.client.post("/api/predict", json=dict(features=notnum)).status_code, 400)

    def test_api_clips_out_of_range(self):
        r = self.client.post("/api/predict", json=dict(features=dict(ORTA, yas=500, aylik_gelir=-5), model="lr"))
        self.assertEqual(r.status_code, 200)


if __name__ == "__main__":
    unittest.main()
